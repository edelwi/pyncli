name = "pyncli"
__version__= '0.1.dev43'