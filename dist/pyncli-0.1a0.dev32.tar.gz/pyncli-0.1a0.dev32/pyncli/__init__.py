name = "pyncli"
__version__= '0.1a0.dev32'